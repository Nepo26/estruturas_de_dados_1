#include <stdio.h>

void main(){

    unsigned int a;

    printf("%i\n",sizeof(a));
}

//Exercicio1 - Extremamente Ba'sico
#include <stdio.h>

void main(){

    //Criando variaveis locais e igualando seu valor a zero
    int a=0,b=0,c=0;
    
    //Lendo valores inseridos pelo usuario e os atribuindo as respectivas  variaveis
    scanf("%d",&a);
    scanf("%d",&b);

    //Atribuindo o valor da soma das variaveis "a" e "b" para a variavel "c"
    c = a + b;

    //Imprimindo na tela o valor da variavel "c"
    printf("X = %d\n",c);


}
